using System;
using System.Collections.Generic;
using HospitalQueue.Models;

namespace HospitalQueue.Services
{
    public class FilaAtendimento
    {
        private Queue<Paciente> filaNormal = new Queue<Paciente>();
        private Queue<Paciente> filaPrioritaria = new Queue<Paciente>();

        public void RegistrarPaciente(Paciente paciente)
        {
            if (paciente.Prioridade)
            {
                filaPrioritaria.Enqueue(paciente);
                Console.WriteLine($"Paciente {paciente.Nome} registrado com prioridade.");
            }
            else
            {
                filaNormal.Enqueue(paciente);
                Console.WriteLine($"Paciente {paciente.Nome} registrado sem prioridade.");
            }
        }

        public void ChamarPaciente()
        {
            if (filaPrioritaria.Count > 0)
            {
                Paciente paciente = filaPrioritaria.Dequeue();
                Console.WriteLine($"Chamando paciente prioritário: {paciente.Nome}");
            }
            else if (filaNormal.Count > 0)
            {
                Paciente paciente = filaNormal.Dequeue();
                Console.WriteLine($"Chamando paciente: {paciente.Nome}");
            }
            else
            {
                Console.WriteLine("Nenhum paciente na fila.");
            }
        }

        public void VerFila()
        {
            Console.WriteLine("\nFila Prioritária:");
            foreach (Paciente paciente in filaPrioritaria)
            {
                Console.WriteLine($"- {paciente.Nome}");
            }

            Console.WriteLine("\nFila Normal:");
            foreach (Paciente paciente in filaNormal)
            {
                Console.WriteLine($"- {paciente.Nome}");
            }
        }
    }
}
