namespace HospitalQueue.Models
{
    public class Paciente
    {
        public string Nome { get; set; }
        public bool Prioridade { get; set; } // True para atendimento prioritário

        public Paciente(string nome, bool prioridade)
        {
            Nome = nome;
            Prioridade = prioridade;
        }
    }
}
