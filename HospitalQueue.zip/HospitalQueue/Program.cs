﻿using System;
using HospitalQueue.Models;
using HospitalQueue.Services;

namespace HospitalQueue
{
    class Program
    {
        static void Main(string[] args)
        {
            FilaAtendimento filaAtendimento = new FilaAtendimento();

            Console.WriteLine("Sistema de Gerenciamento de Filas - Hospital");

            while (true)
            {
                Console.WriteLine("\nEscolha uma opção:");
                Console.WriteLine("1. Registrar Paciente");
                Console.WriteLine("2. Chamar Próximo Paciente");
                Console.WriteLine("3. Ver Fila");
                Console.WriteLine("4. Sair");

                string opcao = Console.ReadLine();

                switch (opcao)
                {
                    case "1":
                        RegistrarPaciente(filaAtendimento);
                        break;
                    case "2":
                        filaAtendimento.ChamarPaciente();
                        break;
                    case "3":
                        filaAtendimento.VerFila();
                        break;
                    case "4":
                        return;
                    default:
                        Console.WriteLine("Opção inválida.");
                        break;
                }
            }
        }

        static void RegistrarPaciente(FilaAtendimento filaAtendimento)
        {
            Console.Write("Digite o nome do paciente: ");
            string nome = Console.ReadLine();

            Console.Write("É um caso prioritário (S/N)? ");
            bool prioridade = Console.ReadLine().ToUpper() == "S";

            Paciente novoPaciente = new Paciente(nome, prioridade);
            filaAtendimento.RegistrarPaciente(novoPaciente);
        }
    }
}
